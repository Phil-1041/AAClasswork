require "byebug"
def first_anagram?(str, target)

  # substrings = []
  # arr = str.split("")
  # (0...arr.length).each do |idx1|
  #   (idx1...arr.length).each do |idx2|
  #     substrings << arr[idx1..idx2].sort.join("")  
  #   end
  # end
  # debugger
  # substrings.include?(target.split("").sort.join(""))

  substrings = str.chars.permutation.to_a
  substrings.include?(target.chars)
end

def second_anagram?(str, target)
  t_arr = target.split("")
  str.each_char do |char|
    i = t_arr.index(char)
    return false if i.nil?
    t_arr.delete_at(i) 
  end
  t_arr.empty?
end

def third_anagram?(str, target)
  str.chars.sort == target.chars.sort
end

def fourth_anagram?(str, target)
  count = Hash.new(0)

  (0...str.length).each do |i|
    count[str[i]] += 1
    count[target[i]] -=1
  end

  count.values.all? { |ele| ele == 0 }


end

# p first_anagram?("gizmo", "sally")    #=> false
# p first_anagram?("elvis", "lives")    #=> true

# p second_anagram?("gizmo", "sally")    #=> false
# p second_anagram?("elvis", "lives")    #=> true

p fourth_anagram?("gizmo", "sally")    #=> false
p fourth_anagram?("elvis", "lives")    #=> true