Rails.application.routes.draw do
  get 'sessions/new'
  get 'sessions/create'
  get 'sessions/destroy'
  resources :users
  resources :links do
    resource :comments, only: [:create]
  end
  resources :comments, except: [:create]

  resource :session
end
