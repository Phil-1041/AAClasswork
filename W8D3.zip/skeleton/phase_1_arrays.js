Array.prototype.uniq = function() {
  let final = [this[0]];
  for (let i=1; i < this.length - 1; i++){
    if (!final.includes(this[i])){
      final.push(this[i]);
    }
  }
  return final;
};

Array.prototype.twoSum = function() {
  let final = [];
  for (let i=0; i < this.length-1; i++){
    for(let j=i+1; j < this.length; j++){
      if (this[i]+this[j]===0){
        final.push([i,j]);
      }
    }    
  }
  return final;
};

Array.prototype.transpose = function () {
  let transposed = [];

  while (transposed.length < this[0].length) {
    for (let i = 0; i < this.length; i++) {
      let row = [];
      for (let j = 0; j < this[0].length; j++) {
        row.push(this[j][i]);
      }
      transposed.push(row);
    }
  }
  return transposed;
};

