Array.prototype.bunnysort = function(){

  sorted = false;
  while (!sorted){
    sorted = true;
    for (let i = 0; i < this.length-1; i++){
      if (this[i] > this[i+1]){
        let temp = this[i];
        let temp2 = this[i+1];
        this[i] = temp2;
        this[i+1] = temp;
        sorted = false;
      }
    }
  }
  return this; 
};

String.prototype.substrings = function () {

  let final = [];
  let before = [];
  for (let i = 0; i < this.length; i++) {
    for (let j = i; j < this.length; j++) {
      before.push(this[j]);
    }
    final.push(before);
    before = [];
  }
  return final;
};

arr = 'hello';
arr.substrings();







