class SessionsController < ApplicationController
#controllers use @variable_name to make sure objects are available in the views
    def new
        render :new
    end
    
    def create
        #validates username and password
        @user = User.find_by_credentials(params[:user][:user_name], params[:user][:password])

        #reset session token and updates session hash
        if !@user.nil? #tests for verification
            session[:session_token] = user.reset_session_token! #resets session token
            redirect_to cats_url #redirects to cat index page if successful
        else
           # flash.now[:errors] = ["Wrong password"]
            render :new
        end
    end

    def destroy
        self.current_user.reset_session_token! if self.current_user
        session[session_token] = ""
        redirect_to new_session_url
    end

end