class ArtworkShare < ApplicationRecord
end
