

function range(start, end) {
  if (start === end) {
    return [];
  }

  return [start] + range(start+1, end);
}

range(5, 14);


function sumRec(arr) {
  if (arr.length === 0) {
    return 0;
  }

  return arr.shift() + sumRec(arr); 
}

sumRec([2, 3, 4]);

function exponent (base, exp) {
  if (exp === 0) {
    return 1;
  }

  return base * exponent(base, exp-1);
}

function exponent2 (base, exp) {
  if (exp === 0) {
    return 1;
  }
  if (exp === 1) {
    return base;
  }

  if (exp % 2 === 0) {
    return exponent2(base, exp/2) ** 2;
  } else {
    return b * (exponent2(base, (exp-1) / 2) ** 2);
  }
}

function deepDup(arr){
  let final = [];
  for (let i = 0; i < arr.length; i ++) {
    let sub = arr[i];
    if (Array.isArray(sub)) {
      final = final.concat([deepDup(sub)]);
    } else {
      final.push(sub);
    }
  }
  return final;
}

function bsearch(arr, target){
  if(arr.length === 0){
    return false;
  }

  let mid = parseInt(arr.length/2);
  if (arr[mid] === target){
    return mid;
  } else if (arr[mid] > target) {
    return bsearch(arr.slice(0, mid), target);
  } else if (arr[mid] < target) {

    let right = bsearch(arr.slice(mid, arr.length), target);
    if (right === false ){
      return false;
    } else {
      return right + mid;
    }
  }
};





