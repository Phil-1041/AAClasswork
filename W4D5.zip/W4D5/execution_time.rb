
require 'byebug'
#  list = [ 0, 3, 5, 4, -5, 10, 1, 90 ]
list = [5, 3, -7]

def my_min(list)
  list.each do |ele|
    return ele if list.all? { |num| num >= ele }
  end
end

# p my_min(list)

def my_min_2(list)
  min = list[0]
  list.each do |ele|
    min = ele if ele < min
  end
  min
end

# p my_min_2(list)

def largest_contiguous_subsum(list)
  subset = []

  (0...list.length).each do |idx1|
    (idx1...list.length).each do |idx2|
      subset << list[idx1..idx2]    #constant
    end
  end
  # debugger
  subset.map! { |sub| sub.sum  } #sub.sum = x?
  subset.max
end
list_2 = [2, 3, -6, 7, -6, 7]
list3 = [-5, -1, -3]
# p largest_contiguous_subsum(list3)

def largest_contiguous_subsum_butter(list)
  biggest = list[0]
  return list.max if list.max < 0
  running_total = list[0]

  (1...list.length).each do |i|
    running_total = 0 if running_total < 0
    if running_total + list[i] <= 0
      running_total = 0
    end
    # debugger
    running_total += list[i]

    biggest = running_total if running_total > biggest 
  end

  return biggest 
end



p largest_contiguous_subsum_butter(list_2)