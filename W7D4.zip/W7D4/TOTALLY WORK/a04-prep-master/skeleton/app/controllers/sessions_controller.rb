class SessionsController < ApplicationController
  def new
  end

  def create
    username = params[:user][:username]
    password = params[:user][:password]
    @user = User.find_by_credentials(username, password)

    if @user 
      login(@user)
      redirect_to links_url
    else
      flash[:errors] = "@user.errors.full_messages"
      render :new
    end
  end

  def destroy
    logout
    render :new
  end
end
