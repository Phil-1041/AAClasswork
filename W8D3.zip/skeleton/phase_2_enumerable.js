Array.prototype.myEach = function (funk) {
  for (let i = 0; i < this.length; i++) {
    funk(this[i]);
  }
};

arr = ["hi", "bye"];
arr.myEach(function funk(el) {
  console.log(el + "!");
});

Array.prototype.myMap = function (func) {
  let result = [];
  this.myEach(function (ele) { result.push(func(ele)) })
  return result;
};

arr = ["hi", "bye"];
arr.myMap(function (el) {
  return el + "bird" + "!";
});


Array.prototype.myReduce = function (func, initialValue) {
  let acc = initialValue ? initialValue : this[0];
  this.myEach(function (ele) { acc += func(ele) })
  return acc;
};

let cheese = function (ele) {
  return ele + 1;
}

arr = [1, 2, 3, 4]
arr.myReduce(cheese, 10);


